﻿using LocationInformationApp.Models;
using Newtonsoft.Json;
using System;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Configuration;

namespace LocationInformationApp.Services
{
    public class WeatherService
    {
        private readonly string apiKey; 

        public WeatherService()
        {
            this.apiKey = WebConfigurationManager.AppSettings["WeatherApiKey"];
        }

        public async Task<WeatherApiResponse> GetWeatherInfo(string zipCode)
        {
            WeatherApiResponse weatherInfo = null; 
            string url = string.Format("http://api.openweathermap.org/data/2.5/weather?zip={0}&APPID={1}", zipCode, this.apiKey);
            
            using (var client = new HttpClient())
            {
                try
                {
                    string json = await client.GetStringAsync(url).ConfigureAwait(false);  
                    weatherInfo = JsonConvert.DeserializeObject<WeatherApiResponse>(json);
                }
                catch (Exception e)
                {
                    throw e;
                }
            }

            return weatherInfo;
        }

        public double ConvertKelvinToFahrenheit(double kelvin)
        {
            return ((kelvin - 273.15) * 1.8) + 32;
        }
    }
}