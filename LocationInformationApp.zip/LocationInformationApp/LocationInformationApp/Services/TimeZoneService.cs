﻿using LocationInformationApp.Models;
using Newtonsoft.Json;
using System;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Configuration;
using System.Web.Script.Serialization;

namespace LocationInformationApp.Services
{
    public class TimeZoneService
    {
        private readonly string apiKey; 

        public TimeZoneService()
        {
            this.apiKey = WebConfigurationManager.AppSettings["GoogleCloudPlatformApiKey"];
        }

        public async Task<TimeZoneApiResponse> GetTimeZoneResponse(double latitude, double longitude, double timestamp)
        {
            TimeZoneApiResponse timeZoneInfo = null;
            string url = string.Format("https://maps.googleapis.com/maps/api/timezone/json?location={0},{1}&timestamp={2}&key={3}", latitude, longitude, timestamp, apiKey);

            using (var client = new HttpClient())
            {
                try
                {
                    string json = await client.GetStringAsync(url).ConfigureAwait(false);
                    timeZoneInfo = JsonConvert.DeserializeObject<TimeZoneApiResponse>(json);
                }
                catch (Exception e)
                {
                    throw e;
                }
            }

            return timeZoneInfo;
        }
    }
}