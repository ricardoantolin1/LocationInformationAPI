﻿using LocationInformationApp.Models;
using Newtonsoft.Json;
using System;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Configuration;
using System.Web.Script.Serialization;

namespace LocationInformationApp.Services
{
    public class ElevationService
    {
        private readonly string apiKey; 

        public ElevationService()
        {
            this.apiKey = WebConfigurationManager.AppSettings["GoogleCloudPlatformApiKey"];
        }

        public async Task<ElevationApiResponse> GetElevationResponse(double latitude, double longitude)
        {
            ElevationApiResponse elevationInfo = null; 
            string url = string.Format("https://maps.googleapis.com/maps/api/elevation/json?locations={0},{1}&key={2}", latitude, longitude, apiKey);
                    
            using (var client = new HttpClient())
            {
                try
                {
                    string json = await client.GetStringAsync(url).ConfigureAwait(false);
                    elevationInfo = JsonConvert.DeserializeObject<ElevationApiResponse>(json);
                }
                catch (Exception e)
                {
                    throw e;
                }
            }

            return elevationInfo;
        }
    }
}