﻿using LocationInformationApp.Models;
using LocationInformationApp.Services;
using System.Linq;

namespace LocationInformationApp.Mappings
{
    public class LocaleInfoMapping
    {
        protected WeatherService WeatherService { get; set; }

        public LocaleInfoMapping()
        {
            this.WeatherService = new WeatherService();
        }

        public LocaleInfo MapToLocaleInfo(WeatherApiResponse weatherResponse, TimeZoneApiResponse timeZoneResponse, ElevationApiResponse elevationResponse)
        {
            LocaleInfo localeInfo = new LocaleInfo();

            if (weatherResponse != null && timeZoneResponse != null && elevationResponse != null)
            {
                localeInfo.CityName = weatherResponse.name;
                if (weatherResponse.main != null && weatherResponse.main.temp != null)
                {
                    localeInfo.Temperature = this.WeatherService.ConvertKelvinToFahrenheit(weatherResponse.main.temp).ToString("0.##");
                }
                localeInfo.TimeZone = timeZoneResponse.timeZoneName;
                localeInfo.Elevation = elevationResponse.results.Any() ? elevationResponse.results.First().elevation.ToString("0.##") : "";
            }

            return localeInfo;
        }
    }
}