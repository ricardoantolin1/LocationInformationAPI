﻿using LocationInformationApp.Mappings;
using LocationInformationApp.Models;
using LocationInformationApp.Services;
using System;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;

namespace LocationInformationApp.Controllers
{
    public class LocaleInformationController : ApiController
    {
        protected WeatherService WeatherService { get; set; }
        protected TimeZoneService TimeZoneService { get; set; }
        protected ElevationService ElevationService { get; set; }
        protected LocaleInfoMapping LocaleInfoMapping { get; set; }

        public LocaleInformationController()
        {
            this.WeatherService = new WeatherService();
            this.TimeZoneService = new TimeZoneService();
            this.ElevationService = new ElevationService();
            this.LocaleInfoMapping = new LocaleInfoMapping();
        }

        /// <summary>
        /// Returns City Name, Current Temperature, Time Zone, Elevation for a given Zip Code
        /// </summary>
        /// <param name="zipCode">Zip Code</param>
        /// <returns>City Name, Current Temperature, Time Zone, and Elevation</returns>
        public IHttpActionResult GetInfo(string zipCode)
        {
            Task<WeatherApiResponse> weatherResponse = null;
            Task<TimeZoneApiResponse> timeZoneResponse = null;
            Task<ElevationApiResponse> elevationResponse = null;

            try
            {
                weatherResponse = this.WeatherService.GetWeatherInfo(zipCode); // synchronous call - coordinates needed for later calls

                var timestamp = DateTime.Now.Subtract(new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc)).TotalSeconds;
                timeZoneResponse = this.TimeZoneService.GetTimeZoneResponse(weatherResponse.Result.coord.lat, weatherResponse.Result.coord.lon, timestamp);

                elevationResponse = this.ElevationService.GetElevationResponse(weatherResponse.Result.coord.lat, weatherResponse.Result.coord.lon);

                LocaleInfo localeInfo = LocaleInfoMapping.MapToLocaleInfo(weatherResponse.Result, timeZoneResponse.Result, elevationResponse.Result);
                string message = string.Format("At the location {0}, the temperature is {1}, the timezone is {2}, and the elevation is {3}",
                    localeInfo.CityName, localeInfo.Temperature, localeInfo.TimeZone, localeInfo.Elevation);

                return Ok(message);
            }
            catch(Exception e)
            {
                var message = new HttpResponseMessage(HttpStatusCode.BadRequest)
                {
                    Content = new StringContent(e.GetBaseException().Message)
                };

                throw new HttpResponseException(message);
            }
        }
    }
}
