﻿namespace LocationInformationApp.Models
{
    public class LocaleInfo
    {
        public string CityName { get; set; }
        public string Temperature { get; set; }
        public string TimeZone { get; set; }
        public string Elevation { get; set; }
    }
}